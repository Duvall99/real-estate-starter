import PropertyCard from '@/components/PropertyCard'

const mockProperties = [
  { id: '1', title: 'Apartment Complex A', price: '$2.5M', location: 'Los Angeles, CA', image: '/images/apartment1.jpg' },
  { id: '2', title: 'Luxury Condos B', price: '$3.1M', location: 'Miami, FL', image: '/images/apartment2.jpg' },
]

export default function MultifamilyPortfolioPage() {
  return (
    <section className="container mx-auto p-6">
      <h1 className="text-4xl font-bold mb-6">Multifamily Portfolio</h1>
      <p>Explore our current multifamily investment opportunities across major U.S. markets.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        {mockProperties.map((prop) => (
          <PropertyCard key={prop.id} property={prop} />
        ))}
      </div>
    </section>
  )
}