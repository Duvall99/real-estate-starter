export default function Hero() {
  return (
    <section className="bg-blue-600 text-white py-20 text-center">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Your Name</h1>
        <p className="text-xl md:text-2xl">Off-Market Residential | Multifamily | Luxury | Commercial | Loan Brokerage</p>
      </div>
    </section>
  )
}