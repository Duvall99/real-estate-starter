import Hero from '../components/Hero'
import Services from '../components/Services'
import NewsletterSignup from '../components/NewsletterSignup'

export default function HomePage() {
  return (
    <>
      <Hero />
      <Services />
      <NewsletterSignup />
    </>
  )
}