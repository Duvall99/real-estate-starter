export default function NewsletterSignup() {
  return (
    <section className="bg-gray-100 p-8 text-center">
      <h2 className="text-2xl font-bold mb-4">Subscribe to Our Insights</h2>
      <p className="mb-6">Get updates on off-market deals, luxury listings, and multifamily opportunities.</p>
      <div className="flex justify-center gap-6">
        <div className="w-full max-w-md">
          <h3 className="font-semibold mb-2">Via Mailchimp</h3>
          <MailchimpForm />
        </div>
        <div className="w-full max-w-md">
          <h3 className="font-semibold mb-2">Via HubSpot</h3>
          <HubSpotForm />
        </div>
      </div>
    </section>
  )
}