import { useState } from 'react'
import Link from 'next/link'

interface Props {
  children: React.ReactNode
}

export default function ProtectedRoute({ children }: Props) {
  const [password, setPassword] = useState('')
  const [authenticated, setAuthenticated] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (password === 'offmarket2025') {
      setAuthenticated(true)
    }
  }

  if (!authenticated) {
    return (
      <div className="container mx-auto p-6 text-center">
        <h2 className="text-2xl font-semibold mb-4">Access Off-Market Listings</h2>
        <form onSubmit={handleSubmit} className="max-w-md mx-auto">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            className="border p-2 w-full mb-4"
            required
          />
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
            Submit
          </button>
        </form>
        <p className="mt-4">
          Need access? <Link href="/contact" className="text-blue-600 underline">Contact us</Link>
        </p>
      </div>
    )
  }

  return <>{children}</>
}