export default function LoanBrokeragePage() {
  return (
    <section className="container mx-auto p-6">
      <h1 className="text-4xl font-bold mb-6">Loan Brokerage</h1>
      <p>We specialize in connecting investors with private lenders and institutional capital for off-market deals, luxury property acquisitions, and commercial real estate investments.</p>

      <h2 className="text-2xl font-semibold mt-6">Our Services Include:</h2>
      <ul className="list-disc pl-6 mt-2 space-y-2">
        <li>Hard Money Loans</li>
        <li>Bridge Financing</li>
        <li>Commercial Lending</li>
        <li>Private Equity Placement</li>
      </ul>
    </section>
  )
}