export default function ServiceCard({ title, description }) {
  return (
    <div className="bg-white p-6 rounded shadow hover:shadow-lg transition-shadow">
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="mt-2">{description}</p>
    </div>
  )
}